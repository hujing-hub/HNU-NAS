from collections import namedtuple


__all__ = ["Genotype", "PRIMITIVES", "ISTA_twostage", "ISTA_onestage", "ISTA_ImageNet"]


Genotype = namedtuple('Genotype', 'normal normal_concat reduce reduce_concat')

PRIMITIVES = [
   'none',
    'max_pool_3x3',
    'avg_pool_3x3',
    'skip_connect',
    'Normal_conv_3x3',
    'Normal_conv_5x5',
    'Normal_conv_7x7',
    'dil_conv_3x3',
    'dil_conv_5x5',
    'dil_conv_7x7',
    'LKA',
    'spectral_conv_3',
    'spectral_conv_5',
    'spectral_conv_7',
    'spatial_conv_3x3',
    'spatial_conv_5x5',
    'spatial_conv_7x7',
    'Channel_Attention',
    'Spatial_Attention',
    '3D_conv_3-3-3',
    '3D_conv_5-3-3',
    '3D_conv_7-3-3',
    'SelfAttention', 
]

ISTA_twostage = Genotype(normal=[('avg_pool_3x3', 1), ('spectral_conv_5', 1), ('avg_pool_3x3', 1), ('spectral_conv_3',  0), ('spatial_conv_7x7', 2), ('spectral_conv_3', 2), ('Normal_conv_5x5', 2), ('LKA', 4)], normal_concat=range(2, 6), reduce=[('avg_pool_3x3', 0), ('spatial_conv_3x3', 1), ('Normal_conv_3x3', 1), ('spatial_conv_5x5', 1), ('Normal_conv_5x5', 1), ('skip_connect', 3), ('avg_pool_3x3', 2), ('spatial_conv_7x7', 2)], reduce_concat=range(2, 6))
