import os
from matplotlib import pyplot as plt
import numpy as np
import torch
import shutil
import torchvision.transforms as transforms
from torch.autograd import Variable
import scipy.io as sio
endmember_number = 3
EPS = 1e-6
class AvgrageMeter(object):

  def __init__(self):
    self.reset()

  def reset(self):
    self.avg = 0
    self.sum = 0
    self.cnt = 0

  def update(self, val, n=1):
    self.sum += val * n
    self.cnt += n
    self.avg = self.sum / self.cnt

def vote(pred_1, pred_2, pred_3, batch_size):
    pred = pred_1
    for i in range(batch_size):
        if pred_2[i].equal(pred_3[i]):
            pred[i] = pred_2[i]
    return pred

class Cutout(object):
    def __init__(self, length):
        self.length = length

    def __call__(self, img):
        h, w = img.size(1), img.size(2)
        mask = np.ones((h, w), np.float32)
        y = np.random.randint(h)
        x = np.random.randint(w)

        y1 = np.clip(y - self.length // 2, 0, h)
        y2 = np.clip(y + self.length // 2, 0, h)
        x1 = np.clip(x - self.length // 2, 0, w)
        x2 = np.clip(x + self.length // 2, 0, w)

        mask[y1: y2, x1: x2] = 0.
        mask = torch.from_numpy(mask)
        mask = mask.expand_as(img)
        img *= mask
        return img


def count_parameters_in_MB(model):
  return np.sum(np.prod(v.size()) for name, v in model.named_parameters() if "auxiliary" not in name)/1e6


def save_checkpoint(state, is_best, save):
  filename = os.path.join(save, 'checkpoint.pth.tar')
  torch.save(state, filename)
  if is_best:
    best_filename = os.path.join(save, 'model_best.pth.tar')
    shutil.copyfile(filename, best_filename)


def save(model, model_path):
  torch.save(model.state_dict(), model_path)


def load(model, model_path):
  model.load_state_dict(torch.load(model_path))


def drop_path(x, drop_prob):
  if drop_prob > 0.:
    keep_prob = 1.-drop_prob
    mask = Variable(torch.cuda.FloatTensor(x.size(0), 1, 1, 1).bernoulli_(keep_prob))
    x.div_(keep_prob)
    x.mul_(mask)
  return x

def create_exp_dir(path, scripts_to_save=None):
  if not os.path.exists(path):
    os.mkdir(path)
  print('Experiment dir : {}'.format(path))

  if scripts_to_save is not None:
    os.mkdir(os.path.join(path, 'scripts'))
    for script in scripts_to_save:
      dst_file = os.path.join(path, 'scripts', os.path.basename(script))
      shutil.copyfile(script, dst_file)

def norm_abundance_GT(abundance_input):

    abundance_input = abundance_input / (torch.sum(abundance_input, dim=1))
    abundance_input = torch.reshape(abundance_input.squeeze(0), (endmember_number, 95, 95))
    abundance_input = abundance_input.cpu().detach().numpy()
   
    return abundance_input




def norm_endmember(endmember_input):

    for i in range(0, endmember_number):
        endmember_input[:, i] = endmember_input[:, i] / np.max(endmember_input[:, i])
       
    return endmember_input


# plot abundance 
def plot_abundance(abundance_input, abundance_GT_input):
    for i in range(0, endmember_number):

        plt.subplot(2, endmember_number, i + 1)
        plt.imshow(abundance_input[i, :, :], cmap="jet")

        plt.subplot(2, endmember_number, endmember_number + i + 1)
        plt.imshow(abundance_GT_input[i, :, :], cmap="jet")
    plt.show()


# plot endmember
def plot_endmember(endmember_input, endmember_GT):
    for i in range(0, endmember_number):
        plt.subplot(1, endmember_number, i + 1)
        plt.plot(endmember_input[:, i], color="b")
        plt.plot(endmember_GT[:, i], color="r")
    plt.show()

    
# calculate RMSE of abundance
def AbundanceRmse(inputsrc, inputref):
    rmse = np.sqrt(((inputsrc - inputref) ** 2).mean())
    return rmse    
# calculate RMSE of abundance
# def AbundanceRmse(inputsrc, inputref):
#     temp=0
#     for i in range(inputsrc.shape[0]):
#         for j in range(inputsrc.shape[1]):
#             temp+=(inputsrc[i][j]-inputref[i][j])**2
#     temp/=(inputsrc.shape[0]*inputsrc.shape[1])
#     temp=temp**(0.5)
#     return temp
def MSE_loss(output, x):
    temp =  torch.sum(x * output, dim=1)/(torch.norm(output, dim=1, p=2)*torch.norm(x, dim=1, p=2) + EPS)
    temp = torch.clamp(temp, -1 + EPS, 1 - EPS)
    MSEloss_value = torch.mean(torch.acos(temp))
    return MSEloss_value  
  
def reconstruction_SADloss(output, target):
    _, band, h, w = output.shape
    output = torch.reshape(output, (band, h * w))
    target = torch.reshape(target, (band, h * w))
    temp = torch.cosine_similarity(output , target , dim=0)
    temp  = torch.clamp(temp, -1 + EPS, 1 - EPS) 
    abundance_loss = torch.acos(temp)
    abundance_loss = torch.mean(abundance_loss)
    return abundance_loss  
   
def SAD_distance(src, ref):
    cos_sim = np.dot(src, ref) / (np.linalg.norm(src) * np.linalg.norm(ref))
    SAD_sim = np.arccos(cos_sim)
    return SAD_sim

def arange_A_E(abundance_input, abundance_GT_input, endmember_input, endmember_GT):
    RMSE_matrix = np.zeros((endmember_number, endmember_number))
    SAD_matrix = np.zeros((endmember_number, endmember_number))
    RMSE_index = np.zeros(endmember_number).astype(int)
    SAD_index = np.zeros(endmember_number).astype(int)
    RMSE_abundance = np.zeros(endmember_number)
    SAD_endmember = np.zeros(endmember_number)

    for i in range(0, endmember_number):
        for j in range(0, endmember_number):
            RMSE_matrix[i, j] = AbundanceRmse(abundance_input[i, :, :], abundance_GT_input[j, :, :])
            SAD_matrix[i, j] = SAD_distance(endmember_input[:, i], endmember_GT[:, j])
        RMSE_index[i] = np.argmin(RMSE_matrix[i, :])
        SAD_index[i] = np.argmin(SAD_matrix[i, :])
        RMSE_abundance[i] = np.min(RMSE_matrix[i, :])
        SAD_endmember[i] = np.min(SAD_matrix[i, :])

    abundance_input[np.arange(endmember_number), :, :] = abundance_input[RMSE_index, :, :]
    endmember_input[:, np.arange(endmember_number)] = endmember_input[:, SAD_index]
    return abundance_input, endmember_input, RMSE_abundance, SAD_endmember

def Reconstruction (abundance,endmember,p):
    one = torch.full((156,95,95),1).cuda()
    p = torch.reshape(p,(156,95,95))
    abundance = torch.reshape(abundance,(3,95,95))
    abundance = abundance.transpose(1,0).transpose(2,1)              
    endmember =endmember.transpose(1,0)
    y = torch.matmul(abundance,endmember)
    y = y.permute(2,0,1)
    temp1 = (one - p) * y 
    temp2 = one - p * y
    x =  torch.div(temp1, temp2+EPS)        
    return x  
  
MSE = torch.nn.MSELoss(reduction='mean') 

def predict(net,path,train_queue):
  net.load_state_dict(torch.load(path + 'weights-result.pth'))
  decoder_para1 = net.state_dict()["decoderlayer2.0.weight"]
  endmember = decoder_para1.cpu().numpy()
  endmember = norm_endmember(endmember)
  for step, (input, target) in enumerate(train_queue):
      input = input.cuda()
      abundance,reconstruction_linear, reconstruction_p= net(input)
      x1 = Reconstruction(abundance,decoder_para1,reconstruction_p)
  en_abundance = norm_abundance_GT(abundance)
  sio.savemat('result/Samson2/samson.mat',{'A':en_abundance,'E':endmember})
