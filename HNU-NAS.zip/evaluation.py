import os
import sys
import time
import glob
from colorama import init
from matplotlib import pyplot as plt
import numpy as np
import scipy
import scipy.io as sio
import torch
from ista_nas import utils
import logging
import argparse
import torch.nn as nn
import genotypes
import torch.utils
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn
from ista_nas.search.models import NetworkCIFAR as Network
from torch.utils.data import TensorDataset, DataLoader
from utils_yhb import *
from torch.autograd import Variable
from tensorboardX import SummaryWriter
from PIL import Image
#from thop import profile
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
os.environ['OMP_NUM_THREADS'] = '2'
col = 95
endmember_number = 3
nBand = 156
path = 'result/Samson2/'
fname1  = "data/Samson/A_true.mat"          
GT_VALUE = scipy.io.loadmat(fname1)["A_true"] 
GT_VALUE = GT_VALUE.transpose(2,0,1)
GT_VALUE = torch.from_numpy(GT_VALUE)     


fname3  = "data/Samson/E.mat"          
mat3 = scipy.io.loadmat(fname3)   
GTEND_VALUE = mat3["E"] 

fname2  = "data/Samson/Y_clean.mat"             
mat2 = scipy.io.loadmat(fname2)   
original_HSI = mat2["Y_clean"]          
original_HSI=original_HSI.transpose(2,0,1)       
original_HSI = torch.from_numpy(original_HSI).unsqueeze(0).float()  

fname4  = "data/Samson/samson_dataset.mat"
mat4 = scipy.io.loadmat(fname4)  
VCA_endmember = mat4["M1"]   #156*3
endmember_init = torch.from_numpy(VCA_endmember).unsqueeze(2).unsqueeze(3).float()  #156*3*1*1
endmember_init1 = torch.from_numpy(VCA_endmember).float()  #156*3

parser = argparse.ArgumentParser("Samson")
parser.add_argument('--data', type=str, default='../data', help='location of the data corpus')
parser.add_argument('--label_file1', type=str, default='data/Samson/E.mat', help='location of the label')
parser.add_argument('--image_file', type=str, default='data/Samson/Y_clean.mat', help='location of the image')
parser.add_argument('--label_file2', type=str, default='data/Samson/A_true.mat', help='location of the label')
parser.add_argument('--batch_size', type=int, default=1, help='batch size')
parser.add_argument('--learning_rate', type=float, default=0.025, help='init learning rate')
parser.add_argument('--momentum', type=float, default=0.9, help='momentum')
parser.add_argument('--weight_decay', type=float, default=3e-4, help='weight decay')
parser.add_argument('--report_freq', type=float, default=50, help='report frequency')
parser.add_argument('--gpu', type=int, default=0, help='gpu device id')
parser.add_argument('--epochs', type=int, default=2000, help='num of training epochs')
parser.add_argument('--init_channels', type=int, default=48, help='num of init channels')
parser.add_argument('--layers', type=int, default=3, help='total number of layers')
parser.add_argument('--model_path', type=str, default='saved_models', help='path to save the model')
parser.add_argument('--auxiliary', action='store_true', default=False, help='use auxiliary tower')
parser.add_argument('--auxiliary_weight', type=float, default=0.4, help='weight for auxiliary loss')
parser.add_argument('--cutout', action='store_true', default=False, help='use cutout')
parser.add_argument('--cutout_length', type=int, default=16, help='cutout length')
parser.add_argument('--drop_path_prob', type=float, default=0.2, help='drop path probability')
parser.add_argument('--save', type=str, default='mid-feature-loss', help='experiment name')
parser.add_argument('--seed', type=int, default=114514, help='random seed')
parser.add_argument('--arch', type=str, default='ISTA_twostage', help='which architecture to use')
parser.add_argument('--grad_clip', type=float, default=5, help='gradient clipping')
parser.add_argument('--onestage', action='store_true', default=False, help='evaluation with one-stage ISTA-NAS architecture')
args = parser.parse_args()

log_format = '%(asctime)s %(message)s'
logging.basicConfig(file_name="eval_log",stream=sys.stdout, level=logging.INFO,
    format=log_format, datefmt='%m/%d %I:%M:%S %p')
fh = logging.FileHandler(os.path.join('eval_log.txt'))
fh.setFormatter(logging.Formatter(log_format))
logging.getLogger().addHandler(fh)

def main():
    if not torch.cuda.is_available():
        logging.info('no gpu device available')
        sys.exit(1)
    writer = SummaryWriter('train_log', comment="Samson")
    np.random.seed(args.seed)
    torch.cuda.set_device(args.gpu)
    cudnn.benchmark = True
    torch.manual_seed(args.seed)
    cudnn.enabled=True
    torch.cuda.manual_seed(args.seed)
    logging.info('gpu device = %d' % args.gpu)
    logging.info("args = %s", args)
    genotype = eval("genotypes.%s" % args.arch)
    
    def weights_init(self):
        for p in self.parameters():
            if p.dim() > 1:
                torch.nn.init.xavier_uniform_(p)
            else:
                torch.nn.init.uniform_(p)

        
    model = Network(nBand, args.init_channels, args.layers, args.auxiliary, genotype).cuda()
    model.apply(weights_init)
    model_dict = model.state_dict() 
    model_dict["decoderlayer2.0.weight"] = endmember_init1
    model.load_state_dict(model_dict)              
    
    logging.info("param size = %fMB", utils.count_parameters_in_MB(model))
    optimizer = torch.optim.SGD(
        model.parameters(),
        args.learning_rate,
        momentum=args.momentum,
        weight_decay=args.weight_decay
        )
    train_queue = DataLoader(TensorDataset(original_HSI,original_HSI), batch_size=1, shuffle=False)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, float(args.epochs))
    checkpoint_save_path = path + 'weights-result.pth'
    best_loss = float('inf')
    for epoch in range(args.epochs):
        scheduler.step()
        model.drop_path_prob = args.drop_path_prob * epoch / args.epochs
        train_loss ,best_loss,checkpoint_save_path = train(train_queue, model, optimizer,epoch,best_loss,checkpoint_save_path)
        writer.add_scalars('train_loss', { 'train_loss': train_loss}, epoch)
    predict(model,path,train_queue)
    
   
def train(train_queue, model, optimizer,epoch,best_loss,checkpoint_save_path):
    losses = utils.AverageMeter()
    MSE = torch.nn.MSELoss(reduction='mean')
    model.train()

    for step, (input, target) in enumerate(train_queue):

        input = Variable(input.cuda(), requires_grad=False)
        target = Variable(target.cuda(non_blocking = True), requires_grad=False)
        optimizer.zero_grad()

        en_abundance, reconstruction_result1,reconstruction_result2=model(input)
        decoder_para1 = model.state_dict()["decoderlayer2.0.weight"]  
        x1 = Reconstruction(en_abundance,decoder_para1,reconstruction_result2)
        x2 = torch.reshape(x1,(1,156,95,95))
        abundanceLoss3 = reconstruction_SADloss(input, reconstruction_result1)
        abundanceLoss1 = reconstruction_SADloss(input, x2)  
        MSELoss3 = MSE_loss(input, x2)
        ALoss =  abundanceLoss3
        BLoss =  abundanceLoss1
        CLoss = MSELoss3
        loss =    ALoss +  BLoss + 0.01 * CLoss       
        loss.backward()
        train_loss = loss.item()
        nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
        optimizer.step()
        n = input.size(0)
        losses.update(loss.data.item(), n)
        print("step: ",epoch , "Loss: ",losses.avg)
       
        if (epoch+1) % 100 == 0:
            decoder_para =decoder_para1.cpu().detach().numpy()
            en_abundance = norm_abundance_GT(en_abundance)
            decoder_para = norm_endmember(decoder_para)
           
            sio.savemat('result/Samson2/samson.mat',{'A':en_abundance,'E':decoder_para})
    if train_loss < best_loss:
        best_loss = train_loss
        torch.save(model.state_dict(), checkpoint_save_path) 
    return  losses.avg,best_loss,checkpoint_save_path
  
if __name__ == '__main__':
  main()
