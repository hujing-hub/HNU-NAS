import sys
import logging
from matplotlib import transforms
import scipy

import torch
import numpy as np
import torchvision.datasets as datasets
import torch.utils.data as data
import scipy.io as sio
from torch.utils.data import TensorDataset, DataLoader
from .search import *
from .recovery import *
from .utils import *

import logging
from tensorboardX import SummaryWriter
import time

__all__ = ["Trainer","load_data"]


log_format = '%(asctime)s %(message)s'
logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                    format=log_format, datefmt='%m/%d %I:%M:%S %p')

  
original_HSI = scipy.io.loadmat('data/Samson/Y_clean.mat')['Y_clean']   
original_HSI=original_HSI.transpose(2,0,1)      
original_HSI = torch.from_numpy(original_HSI).unsqueeze(0).float() 

class load_data(torch.utils.data.Dataset):
    def __init__(self, img, transform=None):
        self.img = img.float()
        self.transform = transform

    def __getitem__(self, idx):
        return self.img
    def __len__(self):
        return 1
    
    
class Trainer:
    def __init__(self, cfg):
        self.cfg = cfg
        self.num_ops      = len(PRIMITIVES)
        self.proj_dims    = cfg.proj_dims
        self.sparseness   = cfg.sparseness
        self.steps        = cfg.steps
        self.seed         = cfg.seed
        self.batch_size   = cfg.batch_size

        self.search_trainer = InnerTrainer(cfg)
        self.num_edges = self.search_trainer.model.num_edges
        self.train_queue, self.valid_queue  = self.set_dataloader()
    
    def set_dataloader(self):
        train_data = DataLoader(TensorDataset(original_HSI,original_HSI), batch_size=1, shuffle=False)
        train_queue = train_data
        valid_queue = train_data
        return train_queue, valid_queue
    
    def do_recovery(self, As, alpha):
        xs = []
        for i in range(self.steps):
            lasso = LASSO(As[i].cpu().numpy().copy())
            b = alpha[i]
            x = lasso.solve(b)
            xs.append(x)
        return xs 
        
    def do_search(self, A_normal, normal_biases,A_reduce, reduce_biases, epoch):       
        self.search_trainer.model.init_proj_mat(A_normal, A_reduce)
        self.search_trainer.model.init_bias(normal_biases, reduce_biases)
        train_loss = self.search_trainer.train_epoch(self.train_queue,self.valid_queue, epoch)
        logging.info("train_loss {:.4f}".format(train_loss))
        valid_loss = self.search_trainer.validate(self.valid_queue)
        logging.info("valid_loss {:.4f}".format(valid_loss))
        
        alpha_normal, alpha_reduce = self.search_trainer.model.arch_parameters()
        alpha_normal = alpha_normal.detach().cpu().numpy()
        alpha_reduce = alpha_reduce.detach().cpu().numpy()

        return alpha_normal, alpha_reduce, train_loss,valid_loss

    def sample_and_proj(self, base_As, xs):
        As= []
        biases = []
        
        for i in range(self.steps):
            A = base_As[i].numpy().copy()
            E = A.T.dot(A) - np.eye(A.shape[1])
            x = xs[i].copy()
            zero_idx = np.abs(x).argsort()[:-self.sparseness]
            x[zero_idx] = 0.
            A[:, zero_idx] = 0.
            As.append(torch.from_numpy(A).float())
            E[:, zero_idx] = 0.
            bias = E.T.dot(x).reshape(-1, self.num_ops)
            biases.append(torch.from_numpy(bias).float())
        
        biases = torch.cat(biases)

        return As, biases

    def show_selected(self, epoch, x_normals, x_reduces):
        
        print("[Epoch {}]".format(epoch if epoch > 0 else 'initial'))
        print("normal cell:")
        gene_normal = []
        for i, x in enumerate(x_normals):
            id1, id2 = np.abs(x).argsort()[-2:]  
            print("Step {}: node{} op{}, node{} op{}".format(
                i + 1, id1 // self.num_ops,
                       id1 % self.num_ops,
                       id2 // self.num_ops,
                       id2 % self.num_ops))
            gene_normal.append((PRIMITIVES[id1 % self.num_ops], id1 // self.num_ops))
            gene_normal.append((PRIMITIVES[id2 % self.num_ops], id2 // self.num_ops))
            
        print("reduction cell:")
        gene_reduce = []
        for i, x in enumerate(x_reduces):
            id1, id2 = np.abs(x).argsort()[-2:]
            print("Step {}: node{} op{}, node{} op{}".format(
                i + 1, id1 // self.num_ops,
                       id1 % self.num_ops,
                       id2 // self.num_ops,
                       id2 % self.num_ops))
            gene_reduce.append((PRIMITIVES[id1 % self.num_ops], id1 // self.num_ops))
            gene_reduce.append((PRIMITIVES[id2 % self.num_ops], id2 // self.num_ops))

        concat = range(2, 2 + len(x_normals))
        genotype = Genotype(
            normal = gene_normal, normal_concat = concat,
            reduce = gene_reduce, reduce_concat = concat)
        print(genotype)
        return genotype

    def train(self):
        base_A_normals = []
        base_A_reduces = []
        writer = SummaryWriter('search_log', comment="Samson")
        logging.basicConfig(stream=sys.stdout, level=logging.INFO, format=log_format, datefmt='%m/%d %I:%M:%S %p')
        fh = logging.FileHandler('log.txt')
        fh.setFormatter(logging.Formatter(log_format))
        logging.getLogger().addHandler(fh)

        for i in range(self.steps):
            base_A_normals.append(
                torch.from_numpy(np.random.rand(self.proj_dims, (i+2) * self.num_ops)))
            base_A_reduces.append(
                torch.from_numpy(np.random.rand(self.proj_dims, (i+2) * self.num_ops)))

        alpha_normal = self.search_trainer.model.alphas_normal_.detach().cpu().numpy()
        alpha_reduce = self.search_trainer.model.alphas_reduce_.detach().cpu().numpy()
        x_normals = self.do_recovery(base_A_normals, alpha_normal)
        x_reduces = self.do_recovery(base_A_reduces, alpha_reduce)
        genotype = self.show_selected(0, x_normals, x_reduces)
        
        for i in range(self.cfg.epochs):
            A_normals, normal_biases = self.sample_and_proj(base_A_normals, x_normals)
            A_reduces, reduce_biases = self.sample_and_proj(base_A_reduces, x_reduces)
            
            print("Doing Search ...")
            alpha_normal, alpha_reduce, train_loss , valid_loss= self.do_search(A_normals, normal_biases,A_reduces, reduce_biases, i+1)
        
            writer.add_scalars('train_loss', {'train_loss': train_loss}, i)
            writer.add_scalars('valid_loss', {'val_loss': valid_loss}, i)
            print("Doing Recovery ...")
            
            x_normals = self.do_recovery(base_A_normals, alpha_normal)
            x_reduces = self.do_recovery(base_A_reduces, alpha_reduce)
            
            
            genotype = self.show_selected(i+1, x_normals, x_reduces)     
            logging.info('epoch:%d , genotype = %s', i,genotype)
            