from collections import namedtuple


__all__ = ["Genotype", "PRIMITIVES"]

Genotype = namedtuple('Genotype', 'normal normal_concat reduce reduce_concat')
PRIMITIVES = [
   'none',
    'max_pool_3x3',
    'avg_pool_3x3',
    'skip_connect',
    'Normal_conv_3x3',
    'Normal_conv_5x5',
    'Normal_conv_7x7',
    'dil_conv_3x3',
    'dil_conv_5x5',
    'LKA',
    'spectral_conv_3',
    'spectral_conv_5',
    'spectral_conv_7',
    'spatial_conv_3x3',
    'spatial_conv_5x5',
    'spatial_conv_7x7',
    'Channel_Attention',
    'Spatial_Attention',
    'SelfAttention', 
    # '3D_conv_3-3-3',
    # '3D_conv_5-3-3',
    # '3D_conv_7-3-3',
]

