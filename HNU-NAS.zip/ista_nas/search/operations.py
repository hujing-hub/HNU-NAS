import torch
import torch.nn as nn

__all__ = ["OPS", "ReLUConvBN","NormalConv", "DilConv", "Conv_3D", "Identity", "Zero", "FactorizedReduce","LKA_Attention","spatial_Attention","ChannelAttention"]


OPS = {
    'none' : lambda C, stride, affine: Zero(stride),
    'avg_pool_3x3' : lambda C, stride, affine: nn.AvgPool2d(3, stride=stride, padding=1, count_include_pad=False),
    'max_pool_3x3' : lambda C, stride, affine: nn.MaxPool2d(3, stride=stride, padding=1),
    'skip_connect' : lambda C, stride, affine: (Identity() if stride == 1 else FactorizedReduce(C, C, affine=affine)),           
    'Normal_conv_3x3' : lambda C, stride, affine: NormalConv(C, C, 3, stride, 1, affine=affine),
    'Normal_conv_5x5' : lambda C, stride, affine: NormalConv(C, C, 5, stride, 2, affine=affine),
    'Normal_conv_7x7' : lambda C, stride, affine: NormalConv(C, C, 7, stride, 3, affine=affine),
    'dil_conv_3x3' : lambda C, stride, affine: DilConv(C, C, 3, stride, 2, 2, affine=affine),
    'dil_conv_5x5' : lambda C, stride, affine: DilConv(C, C, 5, stride, 4, 2, affine=affine),
    'dil_conv_7x7' : lambda C, stride, affine: DilConv(C, C, 7, stride, 4, 2, affine=affine),
    '3D_conv_3-3-3': lambda C, stride, affine: Conv_3D(C, C, kernel=3, stride=stride, padding=1, affine=affine) ,
    '3D_conv_5-3-3': lambda C, stride, affine: Conv_3D(C, C, kernel=5, stride=stride, padding=2, affine=affine) ,
    '3D_conv_7-3-3': lambda C, stride, affine: Conv_3D(C, C, kernel=7, stride=stride, padding=3, affine=affine) ,
    'spectral_conv_3': lambda C, stride, affine: LKA_Attention( C, 3, stride, 1,  affine=affine) ,
    'spectral_conv_5': lambda C, stride, affine: LKA_Attention( C, 5, stride, 2,  affine=affine) ,
    'spectral_conv_7': lambda C, stride, affine: LKA_Attention( C, 7, stride, 3,  affine=affine) ,    
    'LKA': lambda C, stride, affine: LKA1( C,  5, stride, 4,  affine=affine),
    'spatial_conv_3x3': lambda C, stride, affine: spatial_Attention(C, C, 3, stride, 1, affine=affine),
    'spatial_conv_5x5': lambda C, stride, affine: spatial_Attention(C, C, 5, stride, 2, affine=affine),
    'spatial_conv_7x7': lambda C, stride, affine: spatial_Attention(C, C, 7, stride, 3, affine=affine),
    'Channel_Attention' : lambda C, stride, affine: ChannelAttention(C),
    'Spatial_Attention' : lambda C, stride, affine: SpatialAttention(C),
    'SelfAttention' : lambda C, stride, affine: SelfAttention(C),
}
 
class SelfAttention(nn.Module):
    def __init__(self, in_channels):
        super(SelfAttention, self).__init__()
        self.query = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        y = x
        query = self.query(x)
        key = self.key(x)
        value = self.value(x)
        batch_size, num_channels, width, height = x.shape
        query = query.view( num_channels, -1)
        key = key.view( num_channels, -1)
        value = value.view( num_channels, -1)
        
        scores = torch.matmul(query, key.transpose(1,0))
        attention_weights = self.softmax(scores)

        output = torch.matmul(attention_weights, value)
        output = output.view(batch_size, num_channels, width, height)

        return output * y
    
class LKA_Attention(nn.Module):
    def __init__(self, C_in, kernel_size, stride, padding, affine=True):
        super(LKA_Attention, self).__init__()
        self.op = nn.Sequential(
            nn.LeakyReLU(inplace=False),
            nn.Dropout(0.2),
            nn.Conv2d(C_in, C_in, kernel_size, stride, padding, groups=C_in),
            nn.Conv2d(C_in, C_in, 1),
        )
        self.sa = SpatialAttention(C_in)
        self.ca = ChannelAttention(C_in)
        
    def forward(self, x):
        # x = self.sa(x)
        x = self.ca(x) 
        x = self.op(x)
        return x
       
class LKA1(nn.Module):
    def __init__(self, C_in, kernel_size, stride, padding, affine=True):
        super().__init__()
        self.conv0 = nn.Conv2d(C_in, C_in, 5, padding=2, groups=C_in)
        self.conv_spatial = nn.Conv2d(C_in, C_in, 7, stride=stride, padding=9, groups=C_in, dilation=3)
        self.conv1 = nn.Conv2d(C_in, C_in, 1)
        self.stride = stride
        self.pool = nn.Conv2d(C_in, C_in, 3, padding=1, stride=2)

    def forward(self, x):
        if self.stride ==2:
            u=self.pool(x)
        else:
            u = x.clone()        
        attn = self.conv0(x)
        attn = self.conv_spatial(attn)
        attn = self.conv1(attn)
        return u * attn
 
class NormalConv(nn.Module):

    def __init__(self, C_in, C_out, kernel_size, stride, padding, affine=True):
        super(NormalConv, self).__init__()
        self.op = nn.Sequential(
            nn.Conv2d(C_in, C_in, kernel_size=kernel_size, padding=padding, bias=False),
            nn.LeakyReLU(0.2),
            nn.BatchNorm2d(C_in, affine=affine),
            nn.Dropout(0.2),
            nn.Conv2d(C_in, C_in, kernel_size=kernel_size, padding=padding, bias=False),
            nn.LeakyReLU(0.2),
            nn.BatchNorm2d(C_in, affine=affine),
            nn.Dropout(0.2),
            nn.Conv2d(C_in, C_out, kernel_size=kernel_size, padding=padding, bias=False),
        )
        self.ca = ChannelAttention(C_in)
        self.sa = SpatialAttention(C_in)
        self.ca1 = ChannelAttention(C_in)
        self.sa1 = SpatialAttention(C_in)

    def forward(self, x):
        x = self.ca(x)
        x = self.sa(x)
        x = self.op(x)
        x = self.ca1(x) 
        x = self.sa1(x) 
        return x
    

class Conv_3D(nn.Module):

    def __init__(self, C_in, C_out, kernel, stride, padding, affine=True):
        super(Conv_3D, self).__init__()
        self.ops = nn.Sequential(
            nn.Dropout(0.2),
            nn.LeakyReLU(0.2),
            nn.Conv3d(C_out, C_out, (kernel, 1, 1), stride=(1,1,1) ,padding=(padding, 0, 0),bias=False),
            nn.Conv3d(C_out, C_out, (1, 3, 3), stride=(1,stride,stride) ,padding=(0, 1, 1),bias=False),
            nn.BatchNorm3d(C_out, affine=affine),
        )
    
    def forward(self, x):
        x = x.unsqueeze(dim=2)
        x = self.ops(x)
        out = x.squeeze(dim =2)
        return out

class ChannelAttention(nn.Module):
    def __init__(self, in_planes):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1   = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2   = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = x
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        out = self.sigmoid(out) * y
        return out 

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=3):
        super(SpatialAttention, self).__init__()
 
        # assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        # padding = 3 if kernel_size == 7 else 1
        # padding = kernel_size // 2

        self.conv1 = nn.Conv2d(2, 1, 3, padding=1, bias=False)
        self.sigmoid = nn.Sigmoid()
 
    def forward(self, x):
        y = x
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        x = self.sigmoid(x)
        x= x * y
        
        return x 

class spatial_Attention(nn.Module):

    def __init__(self, C_in, C_out, kernel_size, stride, padding, affine=True):
        super(spatial_Attention, self).__init__()
        self.op = nn.Sequential(
            nn.Conv2d(C_in, C_in, kernel_size=(kernel_size,1), stride=(stride,1), padding=(padding,0), groups=C_in, bias=False),
            nn.Dropout(0.2),
            nn.ReLU(inplace=False),
            nn.PReLU(num_parameters=C_in,init=0.25),
            nn.Conv2d(C_in, C_in, kernel_size=(kernel_size,1), stride=(stride,1), padding=(padding,0), groups=C_in, bias=False),
            nn.Conv2d(C_in, C_in, kernel_size=(1,kernel_size), stride=(1,stride), padding=(0,padding), groups=C_in, bias=False),
            nn.Conv2d(C_in, C_out, kernel_size=1, padding=0, bias=False),
            nn.BatchNorm2d(C_out, affine=affine),
           
        )
        self.sa = SpatialAttention(C_in)
        self.ca = ChannelAttention(C_in)
      

    def forward(self, x):
        x = self.sa(x) 
        x = self.op(x)
        return x

class DilConv(nn.Module):
    def __init__(self, C_in, C_out, kernel_size, stride, padding, dilation, affine=True):
        super(DilConv, self).__init__()
        self.op = nn.Sequential(
            nn.Conv2d(C_in, C_in, kernel_size=kernel_size, stride=stride,
                padding=padding, dilation=dilation, groups=C_in, bias=False),
            nn.ReLU(inplace=False),
            nn.BatchNorm2d(C_out, affine=affine))

    def forward(self, x):
        return self.op(x)

class SepConv(nn.Module):
    def __init__(self, C_in, C_out, kernel_size, stride, padding, affine=True):
        super(SepConv, self).__init__()
        
        self.op = nn.Sequential(
            nn.Conv2d(C_in,C_out, kernel_size=kernel_size, stride=stride, padding=padding, groups=C_in, bias=False),
            nn.ReLU(inplace=False),
            nn.Conv2d(C_in, C_in, kernel_size=kernel_size, stride=stride, padding=padding, groups=C_in, bias=False),
            nn.Conv2d(C_in, C_in, kernel_size=1, padding=0, bias=False),
            nn.BatchNorm2d(C_in, affine=affine),
            nn.ReLU(inplace=False),
            nn.Conv2d(C_in, C_in, kernel_size=kernel_size, stride=1, padding=padding, groups=C_in, bias=False),
            nn.Conv2d(C_in, C_out, kernel_size=1, padding=0, bias=False),
            nn.BatchNorm2d(C_out, affine=affine))
        
        self.sa = SpatialAttention()
        self.ca = ChannelAttention(C_in)
        self.ca1 = ChannelAttention(C_in)
        self.sa1 = SpatialAttention()
    def forward(self, x):
        return self.op(x)

class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()

    def forward(self, x):
        return x

class Zero(nn.Module):
    def __init__(self, stride):
        super(Zero, self).__init__()
        self.stride = stride

    def forward(self, x):
        if self.stride == 1:
            return x.mul(0.)
        return x[:,:,::self.stride,::self.stride].mul(0.)

class FactorizedReduce(nn.Module):
    def __init__(self, C_in, C_out, affine=True):
        super(FactorizedReduce, self).__init__()
        assert C_out % 2 == 0
        self.relu = nn.ReLU(inplace=False)
        self.conv_1 = nn.Conv2d(C_in, C_out // 2, 1, stride=1, padding=0, bias=False)
        self.conv_2 = nn.Conv2d(C_in, C_out // 2, 1, stride=1, padding=0, bias=False) 
        self.bn = nn.BatchNorm2d(C_out, affine=affine)

    def forward(self, x):
        x = self.relu(x)
        out = torch.cat([self.conv_1(x), self.conv_2(x)], dim=1)
        out = self.bn(out)
        return out

class ReLUConvBN(nn.Module):
    def __init__(self, C_in, C_out, kernel_size, stride, padding, affine=True):
        super(ReLUConvBN, self).__init__()
        self.op = nn.Sequential(
            nn.ReLU(inplace=False),
            nn.Conv2d(C_in, C_out, kernel_size, stride=stride, padding=padding, bias=False),
            nn.BatchNorm2d(C_out, affine=affine))

    def forward(self, x):
        return self.op(x)
