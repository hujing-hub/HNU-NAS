#from socket import SIO_KEEPALIVE_VALS
import scipy


from ..utils import plot_abundance
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from .outer_trainer import OuterTrainer
from .models import NetWork
from ..utils import *
import numpy as np
from torch.autograd import Variable
import scipy.io as sio
__all__ = ["InnerTrainer"]

GT_VALUE = scipy.io.loadmat('data/Samson/A_true.mat')["A_true"] 
GT_VALUE = GT_VALUE.transpose(2,0,1) 
GT_VALUE = torch.from_numpy(GT_VALUE)     


GTEND_VALUE = scipy.io.loadmat("data/Samson/E.mat")["E"]    



VCA_endmember = scipy.io.loadmat( "data/Samson/samson_dataset.mat")["M1"]  

endmember_init = torch.from_numpy(VCA_endmember).unsqueeze(2).unsqueeze(3).float()  
endmember_init1 = torch.from_numpy(VCA_endmember).float() 
col=95
band_Number=156
endmember_number=3
EPS = 1e-6

def reconstruction_SADloss(output, target):
    _, band, h, w = output.shape
    output = torch.reshape(output, (band, h * w))
    target = torch.reshape(target, (band, h * w))
    temp = torch.cosine_similarity(output , target , dim=0)
    temp  = torch.clamp(temp, -1 + EPS, 1 - EPS) 
    abundance_loss = torch.acos(temp)
    abundance_loss = torch.mean(abundance_loss)
    return abundance_loss

def MSE_loss(output, x):
    temp =  torch.sum(x * output, dim=1)/(torch.norm(output, dim=1, p=2)*torch.norm(x, dim=1, p=2) + EPS)
    temp = torch.clamp(temp, -1 + EPS, 1 - EPS)
    MSEloss_value = torch.mean(torch.acos(temp))
    return MSEloss_value
 

def reset_parameters(self):
    for p in self.parameters():
        if p.dim() > 1:
            torch.nn.init.xavier_uniform_(p)
        else:
            torch.nn.init.uniform_(p)

def reconstruction (abundance,endmember,p):
    one = torch.full((156,95,95),1).cuda()
    p = torch.reshape(p,(156,95,95))
    abundance = torch.reshape(abundance,(3,95,95))
    abundance = abundance.transpose(1,0).transpose(2,1)              
    endmember =endmember.transpose(1,0)
    y = torch.matmul(abundance,endmember)
    y = y.permute(2,0,1)
    temp1 = (one - p) * y 
    temp2 = one - p * y
    x =  torch.div(temp1, temp2+EPS)        
    return x  

class InnerTrainer:
    
    def __init__(self, cfg):
       
        self.grad_clip = cfg.grad_clip
        self.report_freq = cfg.report_freq
        self.batch_size = cfg.batch_size
        self.model = NetWork(cfg.nBand, cfg.init_channels, cfg.num_classes, cfg.layers, proj_dims=cfg.proj_dims).cuda()            
        model = self.model
        model.apply(reset_parameters)
        model_dict = model.state_dict() 
        model_dict["decoderlayer2.0.weight"] = endmember_init1
        model.load_state_dict(model_dict)                
        
        weights = []
        for k, p in self.model.named_parameters():
            if 'alpha' not in k:
                weights.append(p)
        self.optimizer = optim.SGD(
            weights, cfg.learning_rate,
            momentum=cfg.momentum, weight_decay=cfg.weight_decay
        )
        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, float(cfg.epochs), eta_min=cfg.learning_rate_min
        )
        self.outer_trainer = OuterTrainer(self.model, cfg)
    
    
    def train_epoch(self, train_queue, valid_queue, epoch):
        losses = AverageMeter()
        self.scheduler.step()
        lr = self.scheduler.get_lr()
        print('epoch: ', epoch, 'lr:', lr)
        valid_loader =iter(valid_queue)   #valid_queue  
        self.model.train()
        MSE = torch.nn.MSELoss(reduction='mean')
        total_params = sum(p.numel() for p in self.model.parameters())
        for batch_id, (input,target) in enumerate(train_queue):
            input = input.cuda()
            target = target.cuda()
            try:
                input_search, target_search = next(valid_loader)   
            except StopIteration:
                valid_loader =iter(valid_queue)  
                input_search, target_search = next(valid_loader)
            
            input_search =input_search.cuda()     
            target_search =target_search.cuda()  
            
            self.outer_trainer.step(input_search, target_search)
            self.optimizer.zero_grad()
            en_abundance, reconstruction_result1,reconstruction_result2=self.model(input)
            decoder_para1 = self.model.state_dict()["decoderlayer2.0.weight"]  
            x1 = reconstruction(en_abundance,decoder_para1,reconstruction_result2)
            x1 = torch.reshape(x1,(1,156,95,95))
            abundanceLoss3 = reconstruction_SADloss(input, reconstruction_result1)
            abundanceLoss1 = reconstruction_SADloss(input, x1)
            MSELoss3 = MSE_loss(input, x1)
            ALoss =  abundanceLoss3
            BLoss =  abundanceLoss1
            CLoss = MSELoss3
            loss =  ALoss+ 0.1 * BLoss + 0.01 * CLoss
            loss.backward()
            
            nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
            self.optimizer.step()
            n = input.shape[0]
            losses.update(loss.item(), n)

            if batch_id % self.report_freq == 0:
                abundance_GT = GT_VALUE
                GT_endmember = GTEND_VALUE
                abundance_GT = torch.reshape(abundance_GT, (endmember_number, col, col))        
                decoder_para = self.model.state_dict()["decoderlayer2.0.weight"].cpu().numpy()
                en_abundance, abundance_GT = norm_abundance_GT(en_abundance, abundance_GT)
                decoder_para, GT_endmember = norm_endmember(decoder_para, GT_endmember)
                en_abundance, decoder_para, RMSE_abundance, SAD_endmember = arange_A_E(en_abundance, abundance_GT, 
                                                                                    decoder_para, GT_endmember)
                print("Train[{:0>3d}] Loss: {:.4f} ".format(batch_id, losses.avg))
                
                print("Train_mean_SAD", SAD_endmember.mean())
                sio.savemat('result/Samson/samson.mat',{'A':en_abundance,'E':decoder_para})
        
        
        return  losses.avg
    
    
    def validate(self, valid_queue):
        losses = AverageMeter()
        self.model.eval()
        MSE = torch.nn.MSELoss(reduction='mean')
        with torch.no_grad():
            for batch_id, (input,target) in enumerate(valid_queue):
                input = input.cuda()
                target = target.cuda()
                en_abundance, reconstruction_result1,reconstruction_result2=self.model(input)
                decoder_para1 = self.model.state_dict()["decoderlayer2.0.weight"] 
                x1 = reconstruction(en_abundance,decoder_para1,reconstruction_result2)
                x1 = torch.reshape(x1,(1,156,95,95))
                abundanceLoss3 = reconstruction_SADloss(input, reconstruction_result1)
                abundanceLoss1 = reconstruction_SADloss(input, x1)
                MSELoss3 = MSE(input, x1)
                ALoss =  abundanceLoss3
                BLoss =  abundanceLoss1
                CLoss = MSELoss3
                loss =  ALoss+ 0.01 * BLoss + 0.1 * CLoss
                n = input.size(0)
                losses.update(loss.item(), n)

                if batch_id % self.report_freq == 0:
                    abundance_GT = GT_VALUE
                    GT_endmember = GTEND_VALUE
                    abundance_GT = torch.reshape(abundance_GT, (endmember_number, col, col))          
                    decoder_para = self.model.state_dict()["decoderlayer2.0.weight"].cpu().numpy()
                    en_abundance, abundance_GT = norm_abundance_GT(en_abundance, abundance_GT)
                    decoder_para, GT_endmember = norm_endmember(decoder_para, GT_endmember)
                    en_abundance, decoder_para, RMSE_abundance, SAD_endmember = arange_A_E(en_abundance, abundance_GT, 
                                                                                        decoder_para, GT_endmember)
                    print(" Valid[{:0>3d}] Loss: {:.4f} ".format(
                        batch_id, losses.avg,
                    ))
                    print("Train_endmember_SAD", SAD_endmember)
                    sio.savemat('result/Samson/samson2.mat',{'A':en_abundance,'E':decoder_para})

        return losses.avg
     