import torch
import torch.nn as nn
from ..operations import *
from ...utils import drop_path

__all__ = ["NetworkCIFAR"]

class Cell(nn.Module):

  def __init__(self, genotype, C_prev_prev, C_prev, C, reduction, reduction_prev):
    super(Cell, self).__init__()
    if reduction_prev:
      self.preprocess0 = FactorizedReduce(C_prev_prev, C)
    else:
      self.preprocess0 = ReLUConvBN(C_prev_prev, C, 1, 1, 0)
    self.preprocess1 = ReLUConvBN(C_prev, C, 1, 1, 0)
    
    if reduction:
      op_names, indices = zip(*genotype.reduce)   
      concat = genotype.reduce_concat
    else:
      op_names, indices = zip(*genotype.normal)
      concat = genotype.normal_concat
    self._compile(C, op_names, indices, concat, reduction)

  def _compile(self, C, op_names, indices, concat, reduction):
    assert len(op_names) == len(indices)
    self._steps = len(op_names) // 2
    self._concat = concat
    self.multiplier = len(concat)
    self._ops = nn.ModuleList()
    for name, index in zip(op_names, indices):
      stride = 1 if reduction and index < 2 else 1
      op = OPS[name](C, stride, True)
      self._ops += [op]
    self._indices = indices

  def forward(self, s0, s1, drop_prob):
    s0 = self.preprocess0(s0)
    s1 = self.preprocess1(s1)
    states = [s0, s1]
    for i in range(self._steps):
      h1 = states[self._indices[2*i]]
      h2 = states[self._indices[2*i+1]]
      op1 = self._ops[2*i]
      op2 = self._ops[2*i+1]
      h1 = op1(h1)
      h2 = op2(h2)
      if self.training and drop_prob > 0.:
        if not isinstance(op1, Identity):
          h1 = drop_path(h1, drop_prob)
        if not isinstance(op2, Identity):
          h2 = drop_path(h2, drop_prob)
      s = h1 + h2
      states += [s]
    return torch.cat([states[i] for i in self._concat], dim=1)
     
      
class NetworkCIFAR(nn.Module):

  def __init__(self, nBand, C, layers, auxiliary, genotype, multiplier = 4,stem_multiplier=2):
    super(NetworkCIFAR, self).__init__()
    self._layers = layers
    self._auxiliary = auxiliary
    self.nBand = nBand
    stem_multiplier = multiplier
    C_curr = stem_multiplier*C    #C_curr = 192
    self.stem = nn.Sequential(
      nn.Conv2d(nBand, C_curr, 3, stride=1, padding=1, bias=False),
      nn.ReLU(inplace=False),
      nn.BatchNorm2d(C_curr),
      nn.Dropout(0.2),
    )
    self.stem1 = nn.Sequential(
      nn.Conv2d(3, C_curr, 3, stride=1, padding=1, bias=False),
      # nn.ReLU(inplace=False),
      # nn.BatchNorm2d(C_curr),
      # nn.Dropout(0.2),
    )
     
    C_prev_prev, C_prev, C_curr = C_curr, C_curr, C
    self.cells = nn.ModuleList()
    reduction = False
    reduction_prev = False
    
    for i in range(layers):
      if i in [layers//3, 2*layers//3]:
        C_curr *= 2
        reduction = True
      else:
        reduction = False
      cell = Cell(genotype,  C_prev_prev, C_prev, C_curr, reduction, reduction_prev)
      
      reduction_prev = reduction
      self.cells += [cell]
      C_prev_prev, C_prev = C_prev,C_curr * multiplier
      
    self.encodelayer = nn.Sequential(
          nn.Conv2d(C_prev, 3, kernel_size=3, stride=1, padding=1),
          nn.Softmax(dim=2)
      )


    self.decoderlayer1 = nn.Sequential(          
            nn.Conv2d(
                in_channels=C_prev,   
                out_channels=156,
                kernel_size=(1, 1),
                bias=False,
            ),
            nn.Softmax()
        ) 
    self.decoderlayer2 = nn.Sequential(          
        nn.Linear(3, 156, bias=False),
    )

  def forward(self, input):
    logits_aux = None
    s0 = s1 = self.stem(input)
    for i, cell in enumerate(self.cells):
      s0, s1 = s1, cell(s0, s1, self.drop_path_prob)
    en_out = self.encodelayer(s1)
    en_result = torch.transpose(en_out.view((3,95*95)),0,1)
    de_result3 = self.decoderlayer2(en_result)    
    de_result3 = torch.transpose(de_result3,0,1)
    de_result1 = torch.reshape(de_result3, (1,156, 95, 95))  
    
    s2 = s3 = self.stem1(en_out)
    for i, cell in enumerate(self.cells):
      s2, s3 = s3, cell(s2, s3, self.drop_path_prob)
    de_result2 = self.decoderlayer1(s3)
    
    return en_out,de_result1,de_result2
