import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from ..operations import *
from ..genotypes import Genotype, PRIMITIVES

__all__ = ["MixedOp", "Cell", "NetWork"]
EPS = 1e-6
def reconstruction_SADloss(output, target):
    _, band, h, w = output.shape
    output = torch.reshape(output, (band, h * w))
    target = torch.reshape(target, (band, h * w))
    temp = torch.cosine_similarity(output , target , dim=0)
    temp  = torch.clamp(temp, -1 + EPS, 1 - EPS) 
    abundance_loss = torch.acos(temp)
    abundance_loss = torch.mean(abundance_loss)
    return abundance_loss

def MSE_loss(output, x):
    temp =  torch.sum(x * output, dim=1)/(torch.norm(output, dim=1, p=2)*torch.norm(x, dim=1, p=2) + EPS)
    temp = torch.clamp(temp, -1 + EPS, 1 - EPS)
    MSEloss_value = torch.mean(torch.acos(temp))
    return MSEloss_value

def reconstruction (abundance,endmember,p):
    one = torch.full((156,95,95),1).cuda()
    p = torch.reshape(p,(156,95,95))
    abundance = torch.reshape(abundance,(3,95,95))
    abundance = abundance.transpose(1,0).transpose(2,1)              
    endmember =endmember.transpose(1,0)
    y = torch.matmul(abundance,endmember)
    y = y.permute(2,0,1)
    temp1 = (one - p) * y 
    temp2 = one - p * y
    x =  torch.div(temp1, temp2+EPS)        
    return x  

 
class MixedOp(nn.Module):
    def __init__(self, C, stride):
        super(MixedOp, self).__init__()
        self._ops = nn.ModuleList()
        for primitive in PRIMITIVES:   
            op = OPS[primitive](C, stride, False)        
            if 'pool' in primitive:
                op = nn.Sequential(op, nn.BatchNorm2d(C, affine=False))   
            self._ops.append(op)   
    def forward(self, x, weights):
        if weights.sum() == 0:
            return 0
        return sum(w * op(x) for w, op in zip(weights, self._ops) if w != 0)
    
class Cell(nn.Module):
    def __init__(self, steps, multiplier, C_prev_prev, C_prev, C, reduction, reduction_prev):
        super(Cell, self).__init__()
        self.reduction = reduction
        if reduction_prev:
            self.preprocess0 = FactorizedReduce(C_prev_prev, C, affine=False)
        else:
            self.preprocess0 = ReLUConvBN(C_prev_prev, C, 1, 1, 0, affine=False)
        self.preprocess1 = ReLUConvBN(C_prev, C, 1, 1, 0, affine=False) 
        self._steps = steps  
        self._multiplier = multiplier

        self._ops = nn.ModuleList()     
        for i in range(self._steps):
            for j in range(2+i):     
                stride = 1 if reduction and j < 2 else 1
                op = MixedOp(C, stride)   
                self._ops.append(op)  
    def forward(self, s0, s1, weights):
        s0 = self.preprocess0(s0)
        s1 = self.preprocess1(s1)
        states = [s0, s1]   
        offset = 0
        for i in range(self._steps):
            s = sum(self._ops[offset+j](h, weights[offset+j]) for j, h in enumerate(states))
            offset += len(states)
            states.append(s)  
        return torch.cat(states[-self._multiplier:], dim=1)

class NetWork(nn.Module):
    def __init__(self, nBand, C, num_classes, layers, proj_dims=2, steps=4, multiplier=4, stem_multiplier=2):
        super(NetWork, self).__init__()
        self._nBand=nBand
        self._C = C  
        self._num_classes = num_classes
        self._layers = layers
        self._steps = steps  
        self._multiplier = multiplier
        self.num_edges = sum(1 for i in range(self._steps) for n in range(2 + i))
        self.proj_dims = proj_dims
        
        C_curr = stem_multiplier * C    
        self.stem = nn.Sequential(
            nn.Conv2d(nBand, C_curr, 3, stride=1, padding=1, bias=False),
            nn.ReLU(inplace=False),
            nn.BatchNorm2d(C_curr),  
            nn.Dropout(0.2),
        )
        self.stem1 = nn.Sequential(
            nn.Conv2d(3, C_curr, 3, stride=1, padding=1, bias=False),
            )
        C_prev_prev, C_prev, C_curr = C_curr, C_curr, C
        self.cells = nn.ModuleList()
        reduction = False  
        reduction_prev = False
        for i in range(layers):   
            if i in [1,3]:
                C_curr = C_curr*2
                reduction = True
            else:
                reduction = False
            cell = Cell(steps, multiplier, C_prev_prev, C_prev, C_curr, reduction, reduction_prev) 
            reduction_prev = reduction
            self.cells.append(cell)
            C_prev_prev, C_prev = C_prev,  C_curr * multiplier
        
        
        self.encodelayer = nn.Sequential(
            nn.Conv2d(C_prev, 3, kernel_size=3, stride=1, padding=1),
            nn.Softmax()
        )
        self.decoderlayer1 = nn.Sequential(        
            nn.Conv2d(
                in_channels=C_prev,
                out_channels=156,
                kernel_size=(1, 1),
                bias=False,
            ),
        ) 
        self.decoderlayer2 = nn.Sequential(         
            nn.Linear(3, 156, bias=False),
        )
        self._initialize_alphas() 

    def new(self):
        model_new = NetWork(self.nBand, self._C, self._num_classes, self._layers).cuda()
        for x, y in zip(model_new.arch_parameters(), self.arch_parameters()):
            x.data.copy_(y.data)
        return model_new

    def forward(self, input):
        s0 = s1 = self.stem(input)
        self.proj_alphas(self.A_normals, self.A_reduces)
        for i, cell in enumerate(self.cells):
            if cell.reduction:
                weights = self.alphas_reduce
            else:
                weights = self.alphas_normal
            s0, s1 = s1, cell(s0, s1, weights)
        en_out = self.encodelayer(s1)
        en_result = torch.transpose(en_out.view((3,95*95)),0,1)
        de_result3 = self.decoderlayer2(en_result)    
        de_result3 = torch.transpose(de_result3,0,1)
        de_result1 = torch.reshape(de_result3, (1,156, 95, 95))  
        
        s2 = s3 = self.stem1(en_out)
        for i, cell in enumerate(self.cells):
            if cell.reduction:
                weights = self.alphas_reduce
            else:
                weights = self.alphas_normal
            s2, s3 = s3, cell(s2, s3, weights)
        de_result2 = self.decoderlayer1(s3)
        return en_out,de_result1,de_result2

    def _loss(self, input, target):
        en_abundance3, reconstruction_result1,reconstruction_result2 = self(input)
        decoder_para1 = self.state_dict()["decoderlayer2.0.weight"]  
        x1 = reconstruction(en_abundance3,decoder_para1,reconstruction_result2)
        x1 = torch.reshape(x1,(1,156,95,95))
        abundanceLoss3 = reconstruction_SADloss( target, reconstruction_result1)
        abundanceLoss1 = reconstruction_SADloss( target, x1)
        MSELoss3 = MSE_loss(target, x1)
        ALoss =  abundanceLoss3
        BLoss =  abundanceLoss1
        CLoss = MSELoss3
        loss =  ALoss+ 0.1 * BLoss + 0.1 * CLoss
        return loss
    

    def _initialize_alphas(self):
        self.alphas_normal_ = nn.Parameter(1e-3*torch.randn(self._steps, self.proj_dims))
        self.alphas_reduce_ = nn.Parameter(1e-3*torch.randn(self._steps, self.proj_dims))
        self._arch_parameters = [
            self.alphas_normal_,
            self.alphas_reduce_,
        ]

    def init_proj_mat(self, A_normals, A_reduces):
        self.A_normals = A_normals
        self.A_reduces = A_reduces

    def init_bias(self, normal_bias, reduce_bias):
        self.normal_bias = normal_bias
        self.reduce_bias = reduce_bias

    def proj_alphas(self, A_normals, A_reduces):
        assert len(A_normals) == len(A_reduces) == self._steps
        alphas_normal = []
        alphas_reduce = []
        alphas_normal_ = self.alphas_normal_
        alphas_reduce_ = self.alphas_reduce_ 
        for i in range(self._steps):
            A_normal = A_normals[i].to(alphas_normal_.device).requires_grad_(False)
            t_alpha = alphas_normal_[[i]].mm(A_normal).reshape(-1, len(PRIMITIVES))
            alphas_normal.append(t_alpha)
            A_reduce = A_reduces[i].to(alphas_reduce_.device).requires_grad_(False)
            t_alpha = alphas_reduce_[[i]].mm(A_reduce).reshape(-1, len(PRIMITIVES))
            alphas_reduce.append(t_alpha)
        self.alphas_normal = torch.cat(alphas_normal) - self.normal_bias.to(alphas_normal_.device)
        self.alphas_reduce = torch.cat(alphas_reduce) - self.reduce_bias.to(alphas_reduce_.device)


    def arch_parameters(self):
        return self._arch_parameters

    def genotype(self):
        def _parse(weights):
            gene = []
            n = 2
            start = 0
            for i in range(self._steps):
                end = start + n
                W = weights[start:end].copy()
                edges = sorted(range(i + 2),
                    key=lambda x: -max(W[x][k] for k in range(len(W[x]))
                                        if k != PRIMITIVES.index('none')))[:2]
                for j in edges:
                    k_best = None
                    for k in range(len(W[j])):
                        if k != PRIMITIVES.index('none'):
                            if k_best is None or W[j][k] > W[j][k_best]:
                                k_best = k
                    gene.append((PRIMITIVES[k_best], j))
                start = end
                n += 1
            return gene
        gene_normal = _parse(F.softmax(self.alphas_normal, dim=-1).data.cpu().numpy())
        gene_reduce = _parse(F.softmax(self.alphas_reduce, dim=-1).data.cpu().numpy())
        concat = range(2+self._steps-self._multiplier, self._steps+2)
        genotype = Genotype(
            normal=gene_normal, normal_concat=concat,
            reduce=gene_reduce, reduce_concat=concat
        )
        return genotype
